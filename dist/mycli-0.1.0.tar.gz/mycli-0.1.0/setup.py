from setuptools import setup, find_packages

setup(
    name='mycli',
    version='0.1.0',
    author='NeoZ',
    author_email='neoz.blockchain@gmail.com',
    description='A CLI tool for converting PDF into mp3 Audio file',
    packages=find_packages(),
    install_requires=[
        'click',
        # list any other dependencies here
    ],
    entry_points={
        'console_scripts': [
            'mycli=mycli.cli:main',
        ],
    },
)